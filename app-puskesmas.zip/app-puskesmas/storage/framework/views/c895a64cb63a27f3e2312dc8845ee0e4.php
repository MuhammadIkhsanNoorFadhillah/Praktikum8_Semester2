<?php
    $title = "Laporan Program Studi";
    $tahun = 2024;
    $data_mhs = [
        ["prodi" => "SI", "jumlah" => 1020 ],
        ["prodi" => "TI", "jumlah" => 1215 ],
        ["prodi" => "BD", "jumlah" => 62 ],
    ]
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($title); ?></title>
</head>
<body>
    <h1><?php echo e($title); ?> - Tahun <?php echo e($tahun); ?></h1>
    <table border="1">
        <thead>
            <tr>
                <th>Program Studi</th>
                <th>Jumlah Mahasiswa</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data_mhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($mhs['prodi']); ?></td>
                    <td><?php echo e($mhs['jumlah']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\app-puskesmas\resources\views/dashboard/laporan.blade.php ENDPATH**/ ?>