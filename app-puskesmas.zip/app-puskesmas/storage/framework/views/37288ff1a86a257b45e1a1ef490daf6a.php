<h1>Selamat Datang Di Halaman Dashboard</h1>
<?php /**PATH C:\xampp\htdocs\app-puskesmas\resources\views/dashboard/index.blade.php ENDPATH**/ ?>