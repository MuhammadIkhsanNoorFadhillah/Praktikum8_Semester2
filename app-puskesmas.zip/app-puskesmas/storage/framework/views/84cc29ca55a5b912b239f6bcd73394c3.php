<?php
    $username = 'Muhammad Ikhsan Noor Fadhillah';
    $role = 'Ajbj';
?>

<?php if($role =='Admin'): ?>
    <h3>Selamat Datang, <?php echo e($username); ?>! Anda Adalah Seorang <?php echo e($role); ?></h3>
<?php else: ?>
    <h3>Selamat Datang, <?php echo e($username); ?>! Anda Adalah Seorang User</h3>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\app-puskesmas\resources\views/profil.blade.php ENDPATH**/ ?>